$(document).ready(function () {
	$('#mainAdminBtn').click()

	$()

})