# PrettyNoemieCms

CMS offrant à ses utilisateur une solution ergonomique, simple et élégante pour construire en un rien de temps des sites vitrines responsives au design moderne.

Démo

la construction de votre site consistera à agencer à votre convenance des modules variés, d'éditer leurs contenus, et de personnaliser votre site en choisisant les polices de caractère, la mise en forme du texte, ainsi que les couleurs d'affichage

Il a été réalisé par Framasoft et est actuellement utilisé pour construire les pages de Framasite

## Grâce à ses modules variés, il conviendra parfaitement à de nombreuses utilisations :

 - Réalisation d'un CV en ligne
 - Portfolio d'artiste ou de créateur
 - Vitrine de votre association
 - Présentation de votre travail d'artisan
 - Page d'accueil d'un festival
 - Et tout ce que votre créativité en fera ...